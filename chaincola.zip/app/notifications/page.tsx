'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useAppSelector, useAppDispatch } from '../hooks/reduxHooks'
import { clearAllNotifications, removeNotification, updatePreferences } from '../store/slices/notificationSlice'

export default function NotificationsPage() {
  const { notifications, preferences } = useAppSelector((state) => state.notifications)
  const dispatch = useAppDispatch()
  const [filter, setFilter] = useState<'all' | 'info' | 'success' | 'warning' | 'error'>('all')

  const filteredNotifications = notifications.filter(
    notification => filter === 'all' || notification.type === filter
  )

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Notifications</h1>

      <Card>
        <CardHeader>
          <CardTitle>Notification Preferences</CardTitle>
          <CardDescription>Choose how you want to receive notifications</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="email-notifications">Email Notifications</Label>
            <Switch 
              id="email-notifications" 
              checked={preferences.email}
              onCheckedChange={(checked) => dispatch(updatePreferences({ email: checked }))}
            />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="push-notifications">Push Notifications</Label>
            <Switch 
              id="push-notifications" 
              checked={preferences.push}
              onCheckedChange={(checked) => dispatch(updatePreferences({ push: checked }))}
            />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="in-app-notifications">In-App Notifications</Label>
            <Switch 
              id="in-app-notifications" 
              checked={preferences.inApp}
              onCheckedChange={(checked) => dispatch(updatePreferences({ inApp: checked }))}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Notification History</CardTitle>
          <CardDescription>View and manage your notifications</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex justify-between items-center">
            <div className="space-x-2">
              <Button 
                variant={filter === 'all' ? 'default' : 'outline'} 
                onClick={() => setFilter('all')}
              >
                All
              </Button>
              <Button 
                variant={filter === 'info' ? 'default' : 'outline'} 
                onClick={() => setFilter('info')}
              >
                Info
              </Button>
              <Button 
                variant={filter === 'success' ? 'default' : 'outline'} 
                onClick={() => setFilter('success')}
              >
                Success
              </Button>
              <Button 
                variant={filter === 'warning' ? 'default' : 'outline'} 
                onClick={() => setFilter('warning')}
              >
                Warning
              </Button>
              <Button 
                variant={filter === 'error' ? 'default' : 'outline'} 
                onClick={() => setFilter('error')}
              >
                Error
              </Button>
            </div>
            <Button variant="outline" onClick={() => dispatch(clearAllNotifications())}>Clear All</Button>
          </div>
          <ul className="space-y-4">
            {filteredNotifications.map((notification) => (
              <li key={notification.id} className="border-b pb-4 last:border-b-0">
                <h3 className={`font-semibold ${
                  notification.type === 'error' ? 'text-red-600' :
                  notification.type === 'warning' ? 'text-yellow-600' :
                  notification.type === 'success' ? 'text-green-600' :
                  'text-blue-600'
                }`}>
                  {notification.title}
                </h3>
                <p>{notification.message}</p>
                {notification.suggestion && (
                  <p className="mt-2 text-sm font-medium">Suggestion: {notification.suggestion}</p>
                )}
                <p className="mt-1 text-xs text-gray-500">
                  {new Date(notification.timestamp).toLocaleString()}
                </p>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => dispatch(removeNotification(notification.id))}
                  className="mt-2"
                >
                  Dismiss
                </Button>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

