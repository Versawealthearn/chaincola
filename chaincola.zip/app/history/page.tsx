'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Mock data - in a real app, this would come from an API
const transactions = [
  { id: 1, type: 'Deposit', amount: 500, currency: 'USDT', date: '2023-06-01', status: 'Completed' },
  { id: 2, type: 'Transfer', amount: -200, currency: 'ETH', date: '2023-05-30', status: 'Completed' },
  { id: 3, type: 'Swap', amount: 100, currency: 'BTC', date: '2023-05-28', status: 'Completed' },
  { id: 4, type: 'Deposit', amount: 1000, currency: 'BTC', date: '2023-05-25', status: 'Completed' },
  { id: 5, type: 'Transfer', amount: -50, currency: 'XRP', date: '2023-05-22', status: 'Pending' },
]

export default function History() {
  const [filter, setFilter] = useState('all')

  const filteredTransactions = transactions.filter(transaction => 
    filter === 'all' || transaction.type.toLowerCase() === filter
  )

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Transaction History</h1>
      
      <Card>
        <CardHeader>
          <CardTitle>Your Transactions</CardTitle>
          <CardDescription>View and filter your transaction history</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter transactions" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Transactions</SelectItem>
                <SelectItem value="deposit">Deposits</SelectItem>
                <SelectItem value="transfer">Transfers</SelectItem>
                <SelectItem value="swap">Swaps</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Type</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Currency</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTransactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell>{transaction.type}</TableCell>
                  <TableCell className={transaction.amount > 0 ? 'text-green-600' : 'text-red-600'}>
                    {transaction.amount > 0 ? '+' : ''}{transaction.amount}
                  </TableCell>
                  <TableCell>{transaction.currency}</TableCell>
                  <TableCell>{transaction.date}</TableCell>
                  <TableCell>{transaction.status}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

