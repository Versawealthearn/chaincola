'use client'

import { useAppSelector } from './hooks/reduxHooks'
import Navigation from './components/navigation'
import { NotificationProvider } from './contexts/NotificationContext'

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  const theme = useAppSelector((state) => state.theme.mode)

  return (
    <NotificationProvider>
      <div className={`${theme === 'dark' ? 'dark' : ''} flex h-screen bg-gray-100 dark:bg-gray-800`}>
        <Navigation />
        <main className="flex-1 overflow-y-auto p-8">
          {children}
        </main>
      </div>
    </NotificationProvider>
  )
}

