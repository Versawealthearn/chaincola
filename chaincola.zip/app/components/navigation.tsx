'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { Home, Wallet, ArrowLeftRight, RefreshCcw, Clock, Settings, HelpCircle, LogOut, Bell, Sun, Moon, User } from 'lucide-react'
import { useAppDispatch, useAppSelector } from '../hooks/reduxHooks'
import { logoutUser } from '../store/slices/authSlice'
import { toggleTheme } from '../store/slices/themeSlice'
import { useNotification } from '../contexts/NotificationContext'
import { Button } from "@/components/ui/button"

const navItems = [
  { name: 'Dashboard', href: '/dashboard', icon: Home },
  { name: 'Deposit', href: '/deposit', icon: Wallet },
  { name: 'Transfer', href: '/transfer', icon: ArrowLeftRight },
  { name: 'Swap', href: '/swap', icon: RefreshCcw },
  { name: 'History', href: '/history', icon: Clock },
  { name: 'Settings', href: '/settings', icon: Settings },
  { name: 'Support', href: '/support', icon: HelpCircle },
  { name: 'Notifications', href: '/notifications', icon: Bell },
  { name: 'Profile', href: '/profile', icon: User },
]

export default function Navigation() {
  const pathname = usePathname()
  const router = useRouter()
  const dispatch = useAppDispatch()
  const { addNotification } = useNotification()
  const isAuthenticated = useAppSelector((state) => state.auth.isAuthenticated)
  const theme = useAppSelector((state) => state.theme.mode)

  const handleLogout = async () => {
    try {
      await dispatch(logoutUser())
      addNotification('success', 'Logged out successfully', 'You have been logged out of your account.')
      router.push('/login')
    } catch (error) {
      addNotification('error', 'Logout failed', 'An error occurred while trying to log out. Please try again.')
    }
  }

  const handleThemeToggle = () => {
    dispatch(toggleTheme())
  }

  if (!isAuthenticated) {
    return null // Don't render the navigation if the user is not authenticated
  }

  return (
    <nav className="w-64 bg-white dark:bg-gray-800 shadow-md">
      <div className="p-4">
        <h1 className="text-2xl font-bold text-purple-600 dark:text-purple-400">ChainCola</h1>
      </div>
      <ul className="space-y-2 py-4">
        {navItems.map((item) => (
          <li key={item.name}>
            <Link href={item.href} className={`flex items-center px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-purple-100 dark:hover:bg-purple-900 hover:text-purple-600 dark:hover:text-purple-400 ${
              pathname === item.href ? 'bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-400' : ''
            }`}>
              <item.icon className="mr-3 h-5 w-5" />
              {item.name}
            </Link>
          </li>
        ))}
      </ul>
      <div className="absolute bottom-0 w-64 p-4 space-y-2">
        <Button 
          onClick={handleThemeToggle}
          className="flex w-full items-center justify-center px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-purple-100 dark:hover:bg-purple-900 hover:text-purple-600 dark:hover:text-purple-400"
        >
          {theme === 'light' ? <Moon className="mr-3 h-5 w-5" /> : <Sun className="mr-3 h-5 w-5" />}
          {theme === 'light' ? 'Dark Mode' : 'Light Mode'}
        </Button>
        <Button 
          onClick={handleLogout}
          className="flex w-full items-center justify-center px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-purple-100 dark:hover:bg-purple-900 hover:text-purple-600 dark:hover:text-purple-400"
        >
          <LogOut className="mr-3 h-5 w-5" />
          Logout
        </Button>
      </div>
    </nav>
  )
}

