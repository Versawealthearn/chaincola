'use client'

import { useState, useEffect } from 'react'
import { Line } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
)

interface PriceChartProps {
  cryptoId: string
}

export default function PriceChart({ cryptoId }: PriceChartProps) {
  const [chartData, setChartData] = useState<any>(null)

  useEffect(() => {
    // In a real app, you would fetch this data from an API
    const mockData = {
      labels: ['1 Day', '1 Week', '1 Month', '3 Months', '6 Months', '1 Year'],
      datasets: [
        {
          label: 'Price (USD)',
          data: [30000, 32000, 35000, 40000, 38000, 45000],
          borderColor: 'rgb(75, 192, 192)',
          tension: 0.1
        }
      ]
    }
    setChartData(mockData)
  }, [cryptoId])

  if (!chartData) {
    return <div>Loading chart...</div>
  }

  return (
    <Line 
      data={chartData}
      options={{
        responsive: true,
        plugins: {
          legend: {
            position: 'top' as const,
          },
          title: {
            display: true,
            text: `${cryptoId.toUpperCase()} Price Chart`,
          },
        },
      }}
    />
  )
}

