'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useAppSelector, useAppDispatch } from '../hooks/reduxHooks'
import { updateUser } from '../store/slices/authSlice'
import { useNotification } from '../contexts/NotificationContext'

export default function Profile() {
  const dispatch = useAppDispatch()
  const user = useAppSelector((state) => state.auth.user)
  const { addNotification } = useNotification()

  const [name, setName] = useState(user?.name || '')
  const [email, setEmail] = useState(user?.email || '')

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await dispatch(updateUser({ name, email }))
      addNotification('success', 'Profile updated', 'Your profile has been successfully updated.')
    } catch (error) {
      addNotification('error', 'Update failed', 'Failed to update your profile. Please try again.')
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Profile</h1>
      
      <Card>
        <CardHeader>
          <CardTitle>Your Profile</CardTitle>
          <CardDescription>Update your personal information</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div>
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <Button type="submit">Update Profile</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

