'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"

export default function Deposit() {
  const [amount, setAmount] = useState('')
  const [currency, setCurrency] = useState('')
  const { toast } = useToast()

  const handleDeposit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically call an API to process the deposit
    console.log('Depositing:', amount, currency)
    toast({
      title: "Deposit initiated",
      description: `You've initiated a deposit of ${amount} ${currency}.`,
    })
    setAmount('')
    setCurrency('')
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Deposit</h1>
      
      <Card>
        <CardHeader>
          <CardTitle>Deposit Funds</CardTitle>
          <CardDescription>Add funds to your ChainCola account</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleDeposit} className="space-y-4">
            <div>
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="currency">Currency</Label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                  <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                  <SelectItem value="USDT">Tether (USDT)</SelectItem>
                  <SelectItem value="XRP">Ripple (XRP)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button type="submit" className="w-full">Deposit</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Deposit Instructions</CardTitle>
        </CardHeader>
        <CardContent>
          <ol className="list-decimal pl-4 space-y-2">
            <li>Select the cryptocurrency you want to deposit.</li>
            <li>Enter the amount you wish to deposit.</li>
            <li>Click the "Deposit" button to generate a unique deposit address.</li>
            <li>Send your cryptocurrency to the provided address.</li>
            <li>Wait for the transaction to be confirmed on the blockchain.</li>
            <li>Once confirmed, the funds will be credited to your ChainCola account.</li>
          </ol>
        </CardContent>
      </Card>
    </div>
  )
}

