'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useNotification } from '../contexts/NotificationContext'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function Swap() {
  const [fromAmount, setFromAmount] = useState('')
  const [fromCurrency, setFromCurrency] = useState('')
  const [toCurrency, setToCurrency] = useState('')
  const [isConfirmOpen, setIsConfirmOpen] = useState(false)
  const { addNotification } = useNotification()

  const handleSwap = (e: React.FormEvent) => {
    e.preventDefault()
    setIsConfirmOpen(true)
  }

  const handleConfirmedSwap = async () => {
    setIsConfirmOpen(false)
    try {
      // Here you would typically call an API to process the swap
      // For demonstration, we'll simulate an API call
      const response = await simulateSwapApiCall({ fromAmount, fromCurrency, toCurrency })
      if (response.success) {
        addNotification('success', 'Swap initiated', `You've initiated a swap of ${fromAmount} ${fromCurrency} to ${toCurrency}.`)
        setFromAmount('')
        setFromCurrency('')
        setToCurrency('')
      } else {
        throw new Error(response.message || 'Swap failed')
      }
    } catch (error) {
      addNotification(
        'error',
        'Swap failed',
        error instanceof Error ? error.message : 'An unexpected error occurred',
        'Please check the swap details and try again. If the problem persists, contact support.'
      )
    }
  }

  const simulateSwapApiCall = async (swapDetails: { fromAmount: string; fromCurrency: string; toCurrency: string }) => {
    await new Promise(resolve => setTimeout(resolve, 1000)) // Simulate network delay
    if (parseFloat(swapDetails.fromAmount) <= 0) {
      return { success: false, message: 'Swap amount must be greater than 0' }
    }
    if (swapDetails.fromCurrency === swapDetails.toCurrency) {
      return { success: false, message: 'Cannot swap to the same currency' }
    }
    if (Math.random() > 0.2) { // 80% success rate
      return { success: true }
    }
    return { success: false, message: 'Swap failed due to insufficient liquidity' }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Swap</h1>

      <Card>
        <CardHeader>
          <CardTitle>Swap Cryptocurrencies</CardTitle>
          <CardDescription>Exchange one cryptocurrency for another</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSwap} className="space-y-4">
            <div>
              <Label htmlFor="fromAmount">From Amount</Label>
              <Input
                id="fromAmount"
                type="number"
                placeholder="0.00"
                value={fromAmount}
                onChange={(e) => setFromAmount(e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="fromCurrency">From Currency</Label>
              <Select value={fromCurrency} onValueChange={setFromCurrency}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                  <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                  <SelectItem value="USDT">Tether (USDT)</SelectItem>
                  <SelectItem value="XRP">Ripple (XRP)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="toCurrency">To Currency</Label>
              <Select value={toCurrency} onValueChange={setToCurrency}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                  <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                  <SelectItem value="USDT">Tether (USDT)</SelectItem>
                  <SelectItem value="XRP">Ripple (XRP)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button type="submit" className="w-full">Swap</Button>
          </form>
        </CardContent>
      </Card>

      <Dialog open={isConfirmOpen} onOpenChange={setIsConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Swap</DialogTitle>
            <DialogDescription>
              Are you sure you want to swap {fromAmount} {fromCurrency} to {toCurrency}?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConfirmOpen(false)}>Cancel</Button>
            <Button onClick={handleConfirmedSwap}>Confirm Swap</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader>
          <CardTitle>Swap Instructions</CardTitle>
        </CardHeader>
        <CardContent>
          <ol className="list-decimal pl-4 space-y-2">
            <li>Enter the amount you wish to swap.</li>
            <li>Select the cryptocurrency you want to swap from.</li>
            <li>Select the cryptocurrency you want to swap to.</li>
            <li>Review the exchange rate and fees.</li>
            <li>Click the "Swap" button to initiate the exchange.</li>
            <li>Confirm the swap details in the popup window.</li>
            <li>Wait for the swap to be processed.</li>
          </ol>
        </CardContent>
      </Card>
    </div>
  )
}

