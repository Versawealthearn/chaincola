'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"

export default function Support() {
  const [subject, setSubject] = useState('')
  const [message, setMessage] = useState('')
  const { toast } = useToast()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically call an API to submit the support ticket
    console.log('Submitting support ticket:', subject, message)
    toast({
      title: "Support ticket submitted",
      description: "We've received your message and will get back to you soon.",
    })
    setSubject('')
    setMessage('')
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Support Center</h1>
      
      <Card>
        <CardHeader>
          <CardTitle>Contact Support</CardTitle>
          <CardDescription>Get help from our support team</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="subject">Subject</Label>
              <Input
                id="subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="message">Message</Label>
              <Textarea
                id="message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                rows={5}
              />
            </div>
            <Button type="submit">Submit Ticket</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>FAQs</CardTitle>
          <CardDescription>Frequently Asked Questions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold">How do I reset my password?</h3>
              <p>You can reset your password by going to the Settings page and clicking on "Change Password".</p>
            </div>
            <div>
              <h3 className="font-semibold">What cryptocurrencies do you support?</h3>
              <p>We currently support Bitcoin (BTC), Ethereum (ETH), Tether (USDT), and Ripple (XRP).</p>
            </div>
            <div>
              <h3 className="font-semibold">How long do transfers take?</h3>
              <p>Transfer times vary depending on the cryptocurrency and network congestion. Most transfers are completed within an hour.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

