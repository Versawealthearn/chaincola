'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useNotification } from '../contexts/NotificationContext'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function Transfer() {
  const [amount, setAmount] = useState('')
  const [currency, setCurrency] = useState('')
  const [recipient, setRecipient] = useState('')
  const [isConfirmOpen, setIsConfirmOpen] = useState(false)
  const { addNotification } = useNotification()

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsConfirmOpen(true)
  }

  const handleConfirmedTransfer = async () => {
    setIsConfirmOpen(false)
    try {
      // Here you would typically call an API to process the transfer
      // For demonstration, we'll simulate an API call
      const response = await simulateTransferApiCall({ amount, currency, recipient })
      if (response.success) {
        addNotification('success', 'Transfer initiated', `You've initiated a transfer of ${amount} ${currency} to ${recipient}.`)
        setAmount('')
        setCurrency('')
        setRecipient('')
      } else {
        throw new Error(response.message || 'Transfer failed')
      }
    } catch (error) {
      addNotification(
        'error',
        'Transfer failed',
        error instanceof Error ? error.message : 'An unexpected error occurred',
        'Please check your balance and try again. If the problem persists, contact support.'
      )
    }
  }

  const simulateTransferApiCall = async (transferDetails: { amount: string; currency: string; recipient: string }) => {
    await new Promise(resolve => setTimeout(resolve, 1000)) // Simulate network delay
    if (parseFloat(transferDetails.amount) <= 0) {
      return { success: false, message: 'Transfer amount must be greater than 0' }
    }
    if (transferDetails.recipient.length < 5) {
      return { success: false, message: 'Invalid recipient address' }
    }
    if (Math.random() > 0.2) { // 80% success rate
      return { success: true }
    }
    return { success: false, message: 'Transfer failed due to insufficient funds' }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Transfer</h1>

      <Card>
        <CardHeader>
          <CardTitle>Transfer Funds</CardTitle>
          <CardDescription>Send cryptocurrency to an external wallet or bank account</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleTransfer} className="space-y-4">
            <div>
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="currency">Currency</Label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                  <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                  <SelectItem value="USDT">Tether (USDT)</SelectItem>
                  <SelectItem value="XRP">Ripple (XRP)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="recipient">Recipient Address</Label>
              <Input
                id="recipient"
                type="text"
                placeholder="Enter wallet address or bank account"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                required
              />
            </div>
            <Button type="submit" className="w-full">Transfer</Button>
          </form>
        </CardContent>
      </Card>

      <Dialog open={isConfirmOpen} onOpenChange={setIsConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Transfer</DialogTitle>
            <DialogDescription>
              Are you sure you want to transfer {amount} {currency} to {recipient}?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConfirmOpen(false)}>Cancel</Button>
            <Button onClick={handleConfirmedTransfer}>Confirm Transfer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader>
          <CardTitle>Transfer Instructions</CardTitle>
        </CardHeader>
        <CardContent>
          <ol className="list-decimal pl-4 space-y-2">
            <li>Enter the amount you wish to transfer.</li>
            <li>Select the cryptocurrency you want to send.</li>
            <li>Enter the recipient's wallet address or bank account details.</li>
            <li>Double-check all information to ensure accuracy.</li>
            <li>Click the "Transfer" button to initiate the transaction.</li>
            <li>Confirm the transaction details in the popup window.</li>
            <li>Wait for the transaction to be confirmed on the blockchain.</li>
          </ol>
        </CardContent>
      </Card>
    </div>
  )
}

