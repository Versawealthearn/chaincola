import { createSlice, PayloadAction } from '@reduxjs/toolkit'

export type NotificationType = 'info' | 'success' | 'warning' | 'error'

export interface Notification {
  id: string
  type: NotificationType
  title: string
  message: string
  suggestion?: string
  timestamp: number
}

interface NotificationState {
  notifications: Notification[]
  preferences: {
    email: boolean
    push: boolean
    inApp: boolean
  }
}

const initialState: NotificationState = {
  notifications: [],
  preferences: {
    email: true,
    push: true,
    inApp: true,
  },
}

const notificationSlice = createSlice({
  name: 'notifications',
  initialState,
  reducers: {
    addNotification: (state, action: PayloadAction<Omit<Notification, 'id' | 'timestamp'>>) => {
      const newNotification: Notification = {
        ...action.payload,
        id: Date.now().toString(),
        timestamp: Date.now(),
      }
      state.notifications.unshift(newNotification)
    },
    removeNotification: (state, action: PayloadAction<string>) => {
      state.notifications = state.notifications.filter(
        (notification) => notification.id !== action.payload
      )
    },
    clearAllNotifications: (state) => {
      state.notifications = []
    },
    updatePreferences: (state, action: PayloadAction<Partial<NotificationState['preferences']>>) => {
      state.preferences = { ...state.preferences, ...action.payload }
    },
  },
})

export const {
  addNotification,
  removeNotification,
  clearAllNotifications,
  updatePreferences,
} = notificationSlice.actions
export default notificationSlice.reducer

