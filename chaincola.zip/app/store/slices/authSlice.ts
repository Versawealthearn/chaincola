import { createSlice, PayloadAction } from '@reduxjs/toolkit'
import { AppThunk } from '../store'

interface AuthState {
  isAuthenticated: boolean
  user: {
    id: string
    email: string
    name: string
  } | null
}

const initialState: AuthState = {
  isAuthenticated: false,
  user: null,
}

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    login: (state, action: PayloadAction<AuthState['user']>) => {
      state.isAuthenticated = true
      state.user = action.payload
    },
    logout: (state) => {
      state.isAuthenticated = false
      state.user = null
    },
    updateUser: (state, action: PayloadAction<Partial<AuthState['user']>>) => {
      if (state.user) {
        state.user = { ...state.user, ...action.payload }
      }
    },
  },
})

export const { login, logout, updateUser } = authSlice.actions

// Async thunk for logging out
export const logoutUser = (): AppThunk => async (dispatch) => {
  try {
    // Here you would typically call an API to invalidate the session
    // For demonstration, we'll just simulate an API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    dispatch(logout())
  } catch (error) {
    console.error('Logout failed:', error)
    // Here you might want to dispatch an error action
  }
}

export default authSlice.reducer

