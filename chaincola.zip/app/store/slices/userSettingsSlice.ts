import { createSlice, PayloadAction } from '@reduxjs/toolkit'
import { AppThunk } from '../store'

interface UserSettings {
  theme: 'light' | 'dark'
  language: string
  currency: string
}

const initialState: UserSettings = {
  theme: 'light',
  language: 'en',
  currency: 'USD',
}

const userSettingsSlice = createSlice({
  name: 'userSettings',
  initialState,
  reducers: {
    setTheme: (state, action: PayloadAction<'light' | 'dark'>) => {
      state.theme = action.payload
    },
    setLanguage: (state, action: PayloadAction<string>) => {
      state.language = action.payload
    },
    setCurrency: (state, action: PayloadAction<string>) => {
      state.currency = action.payload
    },
  },
})

export const { setTheme, setLanguage, setCurrency } = userSettingsSlice.actions

// Async thunk for updating user settings
export const updateUserSettings = (settings: Partial<UserSettings>): AppThunk => async (dispatch) => {
  try {
    // Simulating an API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    if (settings.theme) dispatch(setTheme(settings.theme))
    if (settings.language) dispatch(setLanguage(settings.language))
    if (settings.currency) dispatch(setCurrency(settings.currency))
  } catch (error) {
    console.error('Failed to update user settings:', error)
    // Here you might want to dispatch an error action
  }
}

export default userSettingsSlice.reducer

