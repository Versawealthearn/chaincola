import { createSlice, PayloadAction } from '@reduxjs/toolkit'
import { AppThunk } from '../store'

interface ThemeState {
  mode: 'light' | 'dark'
}

const initialState: ThemeState = {
  mode: 'light'
}

const themeSlice = createSlice({
  name: 'theme',
  initialState,
  reducers: {
    setTheme: (state, action: PayloadAction<'light' | 'dark'>) => {
      state.mode = action.payload
    }
  }
})

export const { setTheme } = themeSlice.actions

export const toggleTheme = (): AppThunk => (dispatch, getState) => {
  const currentTheme = getState().theme.mode
  dispatch(setTheme(currentTheme === 'light' ? 'dark' : 'light'))
}

export default themeSlice.reducer

