import { createSlice, PayloadAction, createAsyncThunk } from '@reduxjs/toolkit'

interface CryptoData {
  id: string
  name: string
  symbol: string
  price: number
  change24h: number
}

interface CryptoDataState {
  data: CryptoData[]
  status: 'idle' | 'loading' | 'succeeded' | 'failed'
  error: string | null
}

const initialState: CryptoDataState = {
  data: [],
  status: 'idle',
  error: null,
}

// Async thunk for fetching crypto data
export const fetchCryptoData = createAsyncThunk(
  'cryptoData/fetchCryptoData',
  async () => {
    // Simulating an API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    // Mock data
    return [
      { id: 'bitcoin', name: 'Bitcoin', symbol: 'BTC', price: 50000, change24h: 2.5 },
      { id: 'ethereum', name: 'Ethereum', symbol: 'ETH', price: 3000, change24h: 1.8 },
      { id: 'ripple', name: 'Ripple', symbol: 'XRP', price: 1.5, change24h: -0.5 },
    ]
  }
)

const cryptoDataSlice = createSlice({
  name: 'cryptoData',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchCryptoData.pending, (state) => {
        state.status = 'loading'
      })
      .addCase(fetchCryptoData.fulfilled, (state, action: PayloadAction<CryptoData[]>) => {
        state.status = 'succeeded'
        state.data = action.payload
      })
      .addCase(fetchCryptoData.rejected, (state, action) => {
        state.status = 'failed'
        state.error = action.error.message || 'Failed to fetch crypto data'
      })
  },
})

export default cryptoDataSlice.reducer

