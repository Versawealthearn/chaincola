import { createSelector } from '@reduxjs/toolkit'
import { RootState } from '../store'

export const selectDashboardData = createSelector(
  (state: RootState) => state.auth.user,
  (state: RootState) => state.notifications,
  (state: RootState) => state.cryptoData,
  (user, notifications, cryptoData) => ({
    userName: user?.name || 'User',
    recentNotifications: notifications.notifications.slice(0, 5),
    cryptoDataStatus: cryptoData.status,
    cryptoDataError: cryptoData.error,
    cryptoData: cryptoData.data,
  })
)

