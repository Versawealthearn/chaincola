import { configureStore, ThunkAction, Action } from '@reduxjs/toolkit'
import { createWrapper, HYDRATE } from 'next-redux-wrapper'
import { persistStore, persistReducer, FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER } from 'redux-persist'
import storage from 'redux-persist/lib/storage'
import authReducer from './slices/authSlice'
import notificationReducer from './slices/notificationSlice'
import userSettingsReducer from './slices/userSettingsSlice'
import cryptoDataReducer from './slices/cryptoDataSlice'
import themeReducer from './slices/themeSlice'

const authPersistConfig = {
  key: 'auth',
  storage,
  whitelist: ['isAuthenticated', 'user']
}

const themePersistConfig = {
  key: 'theme',
  storage
}

const rootReducer = (state: any, action: any) => {
  if (action.type === HYDRATE) {
    const nextState = {
      ...state, // use previous state
      ...action.payload, // apply delta from hydration
    }
    return nextState
  } else {
    return {
      auth: persistReducer(authPersistConfig, authReducer)(state?.auth, action),
      notifications: notificationReducer(state?.notifications, action),
      userSettings: userSettingsReducer(state?.userSettings, action),
      cryptoData: cryptoDataReducer(state?.cryptoData, action),
      theme: persistReducer(themePersistConfig, themeReducer)(state?.theme, action),
    }
  }
}

export const makeStore = () =>
  configureStore({
    reducer: rootReducer,
    middleware: (getDefaultMiddleware) =>
      getDefaultMiddleware({
        serializableCheck: {
          ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
        },
      }),
    devTools: process.env.NODE_ENV !== 'production',
  })

export type AppStore = ReturnType<typeof makeStore>
export type RootState = ReturnType<AppStore['getState']>
export type AppDispatch = AppStore['dispatch']
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>

export const wrapper = createWrapper<AppStore>(makeStore)

export { makeStore }

