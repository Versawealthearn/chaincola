'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { useAppSelector, useAppDispatch } from '../hooks/reduxHooks'
import { updateUserSettings } from '../store/slices/userSettingsSlice'

export default function Settings() {
  const dispatch = useAppDispatch()
  const { theme, language, currency } = useAppSelector((state) => state.userSettings)
  const [isLoading, setIsLoading] = useState(false)

  const handleUpdateSettings = async () => {
    setIsLoading(true)
    await dispatch(updateUserSettings({ theme, language, currency }))
    setIsLoading(false)
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Settings</h1>

      <Card>
        <CardHeader>
          <CardTitle>User Preferences</CardTitle>
          <CardDescription>Customize your ChainCola experience</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="theme">Theme</Label>
            <Select
              value={theme}
              onValueChange={(value: 'light' | 'dark') => dispatch(updateUserSettings({ theme: value }))}
            >
              <SelectTrigger id="theme">
                <SelectValue placeholder="Select a theme" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="light">Light</SelectItem>
                <SelectItem value="dark">Dark</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="language">Language</Label>
            <Select
              value={language}
              onValueChange={(value: string)Select
              value={language}
              onValueChange={(value: string) => dispatch(updateUserSettings({ language: value }))}
            >
              <SelectTrigger id="language">
                <SelectValue placeholder="Select a language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="es">Español</SelectItem>
                <SelectItem value="fr">Français</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="currency">Currency</Label>
            <Select
              value={currency}
              onValueChange={(value: string) => dispatch(updateUserSettings({ currency: value }))}
            >
              <SelectTrigger id="currency">
                <SelectValue placeholder="Select a currency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="USD">USD</SelectItem>
                <SelectItem value="EUR">EUR</SelectItem>
                <SelectItem value="GBP">GBP</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleUpdateSettings} disabled={isLoading}>
            {isLoading ? 'Updating...' : 'Update Settings'}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

