'use client'

import React, { createContext, useContext, useCallback } from 'react'
import { useToast } from "@/components/ui/use-toast"
import { useAppSelector, useAppDispatch } from '../hooks/reduxHooks'
import { addNotification, removeNotification, clearAllNotifications, updatePreferences } from '../store/slices/notificationSlice'
import { NotificationType } from '../store/slices/notificationSlice'

interface NotificationContextType {
  addNotification: (type: NotificationType, title: string, message: string, suggestion?: string) => void
  removeNotification: (id: string) => void
  clearAllNotifications: () => void
  updatePreferences: (newPreferences: Partial<{ email: boolean; push: boolean; inApp: boolean }>) => void
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined)

export const useNotification = () => {
  const context = useContext(NotificationContext)
  if (!context) {
    throw new Error('useNotification must be used within a NotificationProvider')
  }
  return context
}

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const dispatch = useAppDispatch()
  const { notifications, preferences } = useAppSelector((state) => state.notifications)
  const { toast } = useToast()

  const addNotificationHandler = useCallback((type: NotificationType, title: string, message: string, suggestion?: string) => {
    dispatch(addNotification({ type, title, message, suggestion }))

    if (preferences.inApp) {
      toast({
        title: title,
        description: (
          <div>
            <p>{message}</p>
            {suggestion && <p className="mt-2 text-sm font-medium">Suggestion: {suggestion}</p>}
          </div>
        ),
        variant: type === 'error' ? 'destructive' : 'default',
      })
    }

    // Simulate sending email and push notifications
    if (preferences.email) {
      console.log('Sending email notification:', { type, title, message, suggestion })
    }
    if (preferences.push) {
      console.log('Sending push notification:', { type, title, message, suggestion })
    }
  }, [dispatch, preferences, toast])

  const removeNotificationHandler = useCallback((id: string) => {
    dispatch(removeNotification(id))
  }, [dispatch])

  const clearAllNotificationsHandler = useCallback(() => {
    dispatch(clearAllNotifications())
  }, [dispatch])

  const updatePreferencesHandler = useCallback((newPreferences: Partial<{ email: boolean; push: boolean; inApp: boolean }>) => {
    dispatch(updatePreferences(newPreferences))
  }, [dispatch])

  return (
    <NotificationContext.Provider value={{ 
      addNotification: addNotificationHandler, 
      removeNotification: removeNotificationHandler, 
      clearAllNotifications: clearAllNotificationsHandler,
      updatePreferences: updatePreferencesHandler
    }}>
      {children}
    </NotificationContext.Provider>
  )
}

