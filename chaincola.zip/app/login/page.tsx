'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useNotification } from '../contexts/NotificationContext'
import { useAppDispatch } from '../hooks/reduxHooks'
import { login } from '../store/slices/authSlice'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const router = useRouter()
  const dispatch = useAppDispatch()
  const { addNotification } = useNotification()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      // Here you would typically call an API to authenticate the user
      // For demonstration, we'll simulate an API call
      const response = await simulateApiCall({ email, password })
      if (response.success) {
        dispatch(login({ id: '1', email, name: 'John Doe' }))
        addNotification('success', 'Logged in successfully', 'Welcome back to ChainCola!')
        router.push('/dashboard')
      } else {
        throw new Error(response.message || 'Login failed')
      }
    } catch (error) {
      addNotification(
        'error',
        'Login failed',
        error instanceof Error ? error.message : 'An unexpected error occurred',
        'Please check your email and password, and try again. If the problem persists, contact support.'
      )
    }
  }

  const simulateApiCall = async (credentials: { email: string; password: string }) => {
    await new Promise(resolve => setTimeout(resolve, 1000)) // Simulate network delay
    if (credentials.email === 'test@example.com' && credentials.password === 'password') {
      return { success: true }
    }
    if (!credentials.email.includes('@')) {
      return { success: false, message: 'Invalid email format' }
    }
    if (credentials.password.length < 8) {
      return { success: false, message: 'Password must be at least 8 characters long' }
    }
    return { success: false, message: 'Invalid email or password' }
  }

  return (
    <div className="flex h-screen items-center justify-center bg-gray-100">
      <div className="w-full max-w-md space-y-8 rounded-xl bg-white p-10 shadow-md">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">Sign in to your account</h2>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleLogin}>
          <div className="space-y-4 rounded-md shadow-sm">
            <div>
              <Label htmlFor="email-address">Email address</Label>
              <Input
                id="email-address"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <div>
            <Button type="submit" className="w-full">
              Sign in
            </Button>
          </div>
        </form>
        <div className="text-center text-sm">
          Don't have an account?{' '}
          <Link href="/signup" className="font-medium text-purple-600 hover:text-purple-500">
            Sign up
          </Link>
        </div>
      </div>
    </div>
  )
}

