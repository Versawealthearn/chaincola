'use client'

import { useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowUpRight, ArrowDownRight, RefreshCcw } from 'lucide-react'
import { useAppSelector, useAppDispatch } from '../hooks/reduxHooks'
import { fetchCryptoData } from '../store/slices/cryptoDataSlice'
import { selectDashboardData } from '../store/selectors/dashboardSelectors'
import PriceChart from '../components/PriceChart'

export default function Dashboard() {
  const dispatch = useAppDispatch()
  const { userName, recentNotifications, cryptoDataStatus, cryptoDataError, cryptoData } = useAppSelector(selectDashboardData)

  useEffect(() => {
    if (cryptoDataStatus === 'idle') {
      dispatch(fetchCryptoData())
    }
  }, [cryptoDataStatus, dispatch])

  const balance = 1234.56
  const recentTransactions = [
    { id: 1, type: 'Deposit', amount: 500, currency: 'USDT', date: '2023-06-01' },
    { id: 2, type: 'Transfer', amount: -200, currency: 'ETH', date: '2023-05-30' },
    { id: 3, type: 'Swap', amount: 100, currency: 'BTC', date: '2023-05-28' },
  ]

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Dashboard</h1>
      
      <Card>
        <CardHeader>
          <CardTitle>Welcome, {userName}</CardTitle>
          <CardDescription>Here's an overview of your account</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-3xl font-bold">${balance.toFixed(2)}</p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <Button className="flex items-center justify-center gap-2">
          <ArrowUpRight className="h-4 w-4" />
          Deposit
        </Button>
        <Button className="flex items-center justify-center gap-2">
          <ArrowDownRight className="h-4 w-4" />
          Transfer
        </Button>
        <Button className="flex items-center justify-center gap-2">
          <RefreshCcw className="h-4 w-4" />
          Swap
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Bitcoin Price Chart</CardTitle>
        </CardHeader>
        <CardContent>
          <PriceChart cryptoId="bitcoin" />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Cryptocurrency Prices</CardTitle>
        </CardHeader>
        <CardContent>
          {cryptoDataStatus === 'loading' && <p>Loading cryptocurrency data...</p>}
          {cryptoDataStatus === 'failed' && <p>Error: {cryptoDataError}</p>}
          {cryptoDataStatus === 'succeeded' && (
            <ul className="space-y-2">
              {cryptoData.map((crypto) => (
                <li key={crypto.id} className="flex items-center justify-between">
                  <span>{crypto.name} ({crypto.symbol})</span>
                  <span>${crypto.price.toFixed(2)}</span>
                  <span className={crypto.change24h >= 0 ? 'text-green-600' : 'text-red-600'}>
                    {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h.toFixed(2)}%
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {recentTransactions.map((transaction) => (
              <li key={transaction.id} className="flex items-center justify-between">
                <span>{transaction.type}</span>
                <span className={transaction.amount > 0 ? 'text-green-600' : 'text-red-600'}>
                  {transaction.amount > 0 ? '+' : ''}{transaction.amount} {transaction.currency}
                </span>
                <span className="text-sm text-gray-500">{transaction.date}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Notifications</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {recentNotifications.map((notification) => (
              <li key={notification.id} className="flex items-center justify-between">
                <span className={`font-medium ${
                  notification.type === 'error' ? 'text-red-600' :
                  notification.type === 'warning' ? 'text-yellow-600' :
                  notification.type === 'success' ? 'text-green-600' :
                  'text-blue-600'
                }`}>
                  {notification.title}
                </span>
                <span className="text-sm text-gray-500">{notification.message}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

