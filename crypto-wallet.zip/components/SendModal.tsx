import { useState } from 'react'
import { X } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function SendModal({ onClose }: { onClose: () => void }) {
  const [amount, setAmount] = useState('')
  const [address, setAddress] = useState('')
  const [selectedCoin, setSelectedCoin] = useState('')

  const handleSend = () => {
    // Implement send logic here
    console.log(`Sending ${amount} ${selectedCoin} to ${address}`)
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-green-800 p-6 rounded-lg w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white">Send Cryptocurrency</h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-green-700">
            <X className="h-6 w-6" />
          </Button>
        </div>
        <Select onValueChange={setSelectedCoin}>
          <SelectTrigger className="w-full mb-4 bg-green-700 text-white border-green-600">
            <SelectValue placeholder="Select Coin" />
          </SelectTrigger>
          <SelectContent className="bg-green-700 text-white border-green-600">
            <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
            <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
            <SelectItem value="USDC">USDC</SelectItem>
          </SelectContent>
        </Select>
        <Input
          type="text"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="mb-4 bg-green-700 text-white border-green-600 placeholder-green-400"
        />
        <Input
          type="text"
          placeholder="Recipient Address"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          className="mb-4 bg-green-700 text-white border-green-600 placeholder-green-400"
        />
        <Button onClick={handleSend} className="w-full bg-green-600 text-white hover:bg-green-700">Send</Button>
      </div>
    </div>
  )
}

