import { useState } from 'react'
import { ArrowUpRight, ArrowDownRight, RefreshCcw } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { TransactionDetails } from './TransactionDetails'

export interface Activity {
  id: number;
  type: 'send' | 'receive' | 'convert';
  amount: string;
  currency: string;
  date: string;
  status: 'completed' | 'pending' | 'failed';
}

const mockActivities: Activity[] = [
  { id: 1, type: 'send', amount: '0.1', currency: 'BTC', date: '2023-06-01', status: 'completed' },
  { id: 2, type: 'receive', amount: '500', currency: 'USDC', date: '2023-05-30', status: 'completed' },
  { id: 3, type: 'convert', amount: '1', currency: 'ETH', date: '2023-05-29', status: 'completed' },
  { id: 4, type: 'send', amount: '0.5', currency: 'ETH', date: '2023-05-28', status: 'pending' },
  { id: 5, type: 'receive', amount: '0.05', currency: 'BTC', date: '2023-05-27', status: 'completed' },
]

export function AccountActivities() {
  const [filter, setFilter] = useState<'all' | 'send' | 'receive' | 'convert'>('all')
  const [activities, setActivities] = useState<Activity[]>(mockActivities)
  const [selectedTransaction, setSelectedTransaction] = useState<Activity | null>(null)

  const filteredActivities = filter === 'all' 
    ? activities 
    : activities.filter(activity => activity.type === filter)

  const getActivityIcon = (type: Activity['type']) => {
    switch (type) {
      case 'send':
        return <ArrowUpRight className="h-4 w-4 text-red-500" />
      case 'receive':
        return <ArrowDownRight className="h-4 w-4 text-green-500" />
      case 'convert':
        return <RefreshCcw className="h-4 w-4 text-blue-500" />
    }
  }

  return (
    <div className="bg-green-800 rounded-lg p-4">
      <h2 className="text-xl font-bold text-white mb-4">Account Activities</h2>
      <div className="flex justify-between items-center mb-4">
        <Select onValueChange={(value) => setFilter(value as any)}>
          <SelectTrigger className="w-[180px] bg-green-700 text-white border-green-600">
            <SelectValue placeholder="Filter activities" />
          </SelectTrigger>
          <SelectContent className="bg-green-700 text-white border-green-600">
            <SelectItem value="all">All Activities</SelectItem>
            <SelectItem value="send">Send</SelectItem>
            <SelectItem value="receive">Receive</SelectItem>
            <SelectItem value="convert">Convert</SelectItem>
          </SelectContent>
        </Select>
        <Button 
          variant="outline" 
          onClick={() => setActivities(mockActivities)}
          className="bg-green-700 text-white border-green-600 hover:bg-green-600"
        >
          Refresh
        </Button>
      </div>
      <ScrollArea className="h-[300px]">
        <ul className="space-y-2">
          {filteredActivities.map((activity) => (
            <li 
              key={activity.id} 
              className="bg-green-700 p-3 rounded-lg flex items-center justify-between cursor-pointer hover:bg-green-600 transition-colors"
              onClick={() => setSelectedTransaction(activity)}
            >
              <div className="flex items-center space-x-3">
                {getActivityIcon(activity.type)}
                <div>
                  <p className="text-white font-medium">
                    {activity.type.charAt(0).toUpperCase() + activity.type.slice(1)} {activity.amount} {activity.currency}
                  </p>
                  <p className="text-green-300 text-sm">{activity.date}</p>
                </div>
              </div>
              <span className={`text-sm ${
                activity.status === 'completed' ? 'text-green-400' :
                activity.status === 'pending' ? 'text-yellow-400' :
                'text-red-400'
              }`}>
                {activity.status.charAt(0).toUpperCase() + activity.status.slice(1)}
              </span>
            </li>
          ))}
        </ul>
      </ScrollArea>
      {selectedTransaction && (
        <TransactionDetails 
          transaction={selectedTransaction} 
          onClose={() => setSelectedTransaction(null)} 
        />
      )}
    </div>
  )
}

