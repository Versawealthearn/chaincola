import React, { useState, useEffect } from 'react'
import { ArrowRight, Shield, Zap, RefreshCw, TrendingUp, DollarSign, Lock, Globe, Smartphone, Gift } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { LoginModal } from './LoginModal'
import { SignupModal } from './SignupModal'

interface LandingPageProps {
  onLogin: (email: string, password: string) => void;
  onSignup: (email: string, password: string) => void;
}

interface CryptoPrice {
  id: string;
  name: string;
  price: number;
  change24h: number;
}

const LandingPage: React.FC<LandingPageProps> = ({ onLogin, onSignup }) => {
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showSignupModal, setShowSignupModal] = useState(false)
  const [cryptoPrices, setCryptoPrices] = useState<CryptoPrice[]>([])

  useEffect(() => {
    // Simulating API call for crypto prices
    const mockPrices: CryptoPrice[] = [
      { id: 'bitcoin', name: 'Bitcoin', price: 45000, change24h: 2.5 },
      { id: 'ethereum', name: 'Ethereum', price: 3200, change24h: -1.2 },
      { id: 'cardano', name: 'Cardano', price: 1.5, change24h: 5.7 },
      { id: 'dogecoin', name: 'Dogecoin', price: 0.25, change24h: 10.1 },
    ]
    setCryptoPrices(mockPrices)

    // Simulating live price updates
    const interval = setInterval(() => {
      setCryptoPrices(prices => 
        prices.map(price => ({
          ...price,
          price: price.price * (1 + (Math.random() - 0.5) * 0.01),
          change24h: price.change24h + (Math.random() - 0.5)
        }))
      )
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-green-900 text-white">
      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Navigation */}
        <nav className="flex justify-between items-center mb-16">
          <h1 className="text-2xl font-bold">ChainCola</h1>
          <div className="space-x-4">
            <Button variant="outline" onClick={() => setShowLoginModal(true)} className="bg-green-600 text-white hover:bg-green-700">
              Sign In
            </Button>
            <Button onClick={() => setShowSignupModal(true)} className="bg-green-600 text-white hover:bg-green-700">
              Sign Up
            </Button>
          </div>
        </nav>

        {/* Hero Section */}
        <header className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">Welcome to ChainCola</h1>
          <p className="text-xl md:text-2xl text-green-300 mb-8">Your refreshing gateway to blockchain and cryptocurrency</p>
          <Button className="bg-green-600 text-white hover:bg-green-700 text-lg px-8 py-6" onClick={() => setShowSignupModal(true)}>
            Start Your Crypto Journey
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </header>

        {/* Live Price Ticker */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Live Cryptocurrency Prices</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {cryptoPrices.map((crypto) => (
              <Card key={crypto.id} className="bg-green-800 border-green-700">
                <CardContent className="p-4">
                  <h3 className="text-lg font-semibold mb-2">{crypto.name}</h3>
                  <p className="text-2xl font-bold">${crypto.price.toFixed(2)}</p>
                  <p className={`text-sm ${crypto.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {crypto.change24h >= 0 ? '▲' : '▼'} {Math.abs(crypto.change24h).toFixed(2)}%
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Features Section */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Why Choose ChainCola?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Shield className="h-12 w-12 text-green-400" />}
              title="Uncompromising Security"
              description="State-of-the-art encryption and multi-signature wallets keep your assets safe."
            />
            <FeatureCard 
              icon={<Zap className="h-12 w-12 text-green-400" />}
              title="Lightning-Fast Trades"
              description="Execute trades in milliseconds with our high-frequency trading engine."
            />
            <FeatureCard 
              icon={<RefreshCw className="h-12 w-12 text-green-400" />}
              title="Seamless Conversions"
              description="Swap between cryptocurrencies with zero fees and minimal slippage."
            />
          </div>
        </section>

        {/* Additional Features Section */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Discover ChainCola's Unique Features</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Globe className="h-12 w-12 text-green-400" />}
              title="Global Accessibility"
              description="Trade from anywhere in the world with our decentralized platform."
            />
            <FeatureCard 
              icon={<Smartphone className="h-12 w-12 text-green-400" />}
              title="Mobile-First Design"
              description="Manage your portfolio on-the-go with our intuitive mobile app."
            />
            <FeatureCard 
              icon={<Gift className="h-12 w-12 text-green-400" />}
              title="Rewards Program"
              description="Earn ChainCola tokens for every trade and referral you make."
            />
          </div>
        </section>

        {/* Benefits Section */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Benefits of Using Our Platform</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <BenefitCard 
              icon={<TrendingUp className="h-8 w-8 text-green-400" />}
              title="Advanced Trading Tools"
              description="Access real-time market data, AI-powered predictions, and advanced charting tools."
            />
            <BenefitCard 
              icon={<DollarSign className="h-8 w-8 text-green-400" />}
              title="Competitive Fees"
              description="Enjoy some of the lowest fees in the industry, with discounts for high-volume traders."
            />
            <BenefitCard 
              icon={<Lock className="h-8 w-8 text-green-400" />}
              title="Regulatory Compliance"
              description="Trade with confidence knowing we adhere to strict regulatory standards globally."
            />
          </div>
        </section>

        {/* CTA Section */}
        <section className="text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to revolutionize your crypto experience?</h2>
          <p className="text-xl text-green-300 mb-8">Join thousands of satisfied users who trust ChainCola for their crypto journey.</p>
          <Button className="bg-green-600 text-white hover:bg-green-700 text-lg px-8 py-6" onClick={() => setShowSignupModal(true)}>
            Join ChainCola Now
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </section>
        <footer className="mt-16 text-center">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="text-lg font-semibold mb-2">Contact Us</h3>
              <p className="text-green-300">123 Crypto Street, Blockchain City, BC 12345</p>
              <p className="text-green-300">Email: support@chaincola.com</p>
              <p className="text-green-300">Phone: +1 (555) 123-4567</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Follow Us</h3>
              <div className="flex justify-center space-x-4">
                <a href="https://twitter.com/chaincola" target="_blank" rel="noopener noreferrer" className="text-green-300 hover:text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path></svg>
                </a>
                <a href="https://facebook.com/chaincola" target="_blank" rel="noopener noreferrer" className="text-green-300 hover:text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
                </a>
                <a href="https://instagram.com/chaincola" target="_blank" rel="noopener noreferrer" className="text-green-300 hover:text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
                </a>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Legal</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-green-300 hover:text-white">Terms of Service</a></li>
                <li><a href="#" className="text-green-300 hover:text-white">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
          <p className="text-green-300">&copy; 2023 ChainCola. All rights reserved.</p>
        </footer>
      </div>

      {showLoginModal && (
        <LoginModal
          onClose={() => setShowLoginModal(false)}
          onLogin={onLogin}
        />
      )}
      {showSignupModal && (
        <SignupModal
          onClose={() => setShowSignupModal(false)}
          onSignup={onSignup}
        />
      )}
    </div>
  )
}

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => {
  return (
    <Card className="bg-green-800 border-green-700">
      <CardContent className="p-6 text-center">
        <div className="flex justify-center mb-4">{icon}</div>
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p className="text-green-300">{description}</p>
      </CardContent>
    </Card>
  )
}

const BenefitCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => {
  return (
    <div className="flex items-start space-x-4">
      <div className="flex-shrink-0">{icon}</div>
      <div>
        <h3 className="text-lg font-semibold mb-2">{title}</h3>
        <p className="text-green-300">{description}</p>
      </div>
    </div>
  )
}

export default LandingPage

