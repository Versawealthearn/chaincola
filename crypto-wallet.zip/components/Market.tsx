import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

const mockP2POffers = [
  { id: 1, user: 'Alice', price: '35,000', amount: '0.5 BTC', paymentMethod: 'Bank Transfer' },
  { id: 2, user: 'Bob', price: '34,800', amount: '0.3 BTC', paymentMethod: 'PayPal' },
  { id: 3, user: 'Charlie', price: '35,200', amount: '0.7 BTC', paymentMethod: 'Cash' },
]

const paymentMethods = ['Bank Transfer', 'PayPal', 'Cash', 'Credit Card', 'Venmo']

export function Market() {
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string | undefined>()

  return (
    <div className="space-y-6">
      <Card className="bg-green-800 border-green-700">
        <CardContent className="p-4">
          <h2 className="text-xl font-bold text-white mb-4">P2P Market</h2>
          <div className="flex gap-4 mb-4">
            <Input 
              placeholder="Search offers" 
              className="bg-green-700 text-white border-green-600 placeholder-green-400"
            />
            <Select onValueChange={setSelectedPaymentMethod}>
              <SelectTrigger className="w-[180px] bg-green-700 text-white border-green-600">
                <SelectValue placeholder="Payment Method" />
              </SelectTrigger>
              <SelectContent className="bg-green-700 text-white border-green-600">
                {paymentMethods.map((method) => (
                  <SelectItem key={method} value={method}>{method}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-green-300">User</TableHead>
                <TableHead className="text-green-300">Price (USD)</TableHead>
                <TableHead className="text-green-300">Amount</TableHead>
                <TableHead className="text-green-300">Payment Method</TableHead>
                <TableHead className="text-green-300">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockP2POffers.map((offer) => (
                <TableRow key={offer.id}>
                  <TableCell className="text-white">{offer.user}</TableCell>
                  <TableCell className="text-white">{offer.price}</TableCell>
                  <TableCell className="text-white">{offer.amount}</TableCell>
                  <TableCell className="text-white">{offer.paymentMethod}</TableCell>
                  <TableCell>
                    <Button className="bg-green-600 text-white hover:bg-green-700">Buy</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <Card className="bg-green-800 border-green-700">
        <CardContent className="p-4">
          <h2 className="text-xl font-bold text-white mb-4">Payment Methods</h2>
          <ul className="space-y-2">
            {paymentMethods.map((method) => (
              <li key={method} className="flex items-center justify-between bg-green-700 p-3 rounded-lg">
                <span className="text-white">{method}</span>
                <Button variant="outline" className="bg-green-600 text-white hover:bg-green-700">
                  Add
                </Button>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

