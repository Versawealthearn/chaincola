import { useState } from 'react'
import { X, ArrowRight } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function ConvertModal({ onClose }: { onClose: () => void }) {
  const [fromCoin, setFromCoin] = useState('')
  const [toCoin, setToCoin] = useState('')
  const [amount, setAmount] = useState('')

  const handleConvert = () => {
    // Implement conversion logic here
    console.log(`Converting ${amount} ${fromCoin} to ${toCoin}`)
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-green-800 p-6 rounded-lg w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white">Convert Cryptocurrency</h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-green-700">
            <X className="h-6 w-6" />
          </Button>
        </div>
        <div className="flex items-center mb-4">
          <Select onValueChange={setFromCoin} className="flex-1">
            <SelectTrigger className="bg-green-700 text-white border-green-600">
              <SelectValue placeholder="From" />
            </SelectTrigger>
            <SelectContent className="bg-green-700 text-white border-green-600">
              <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
              <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
              <SelectItem value="USDC">USDC</SelectItem>
            </SelectContent>
          </Select>
          <ArrowRight className="mx-2 text-white" />
          <Select onValueChange={setToCoin} className="flex-1">
            <SelectTrigger className="bg-green-700 text-white border-green-600">
              <SelectValue placeholder="To" />
            </SelectTrigger>
            <SelectContent className="bg-green-700 text-white border-green-600">
              <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
              <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
              <SelectItem value="USDC">USDC</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Input
          type="text"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="mb-4 bg-green-700 text-white border-green-600 placeholder-green-400"
        />
        <Button onClick={handleConvert} className="w-full bg-green-600 text-white hover:bg-green-700">Convert</Button>
      </div>
    </div>
  )
}

