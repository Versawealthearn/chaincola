import { X } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

interface Notification {
  id: number;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
}

export function NotificationsModal({ onClose, notifications }: { onClose: () => void, notifications: Notification[] }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-start justify-end p-4">
      <div className="bg-green-800 p-6 rounded-lg w-full max-w-md mt-16 mr-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white">Notifications</h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-green-700">
            <X className="h-6 w-6" />
            <span className="sr-only">Close notifications</span>
          </Button>
        </div>
        <ScrollArea className="h-[400px] pr-4">
          {notifications.length > 0 ? (
            <ul className="space-y-4">
              {notifications.map((notification) => (
                <li key={notification.id} className={`bg-green-700 p-4 rounded-lg ${notification.read ? 'opacity-50' : ''}`}>
                  <h3 className="font-semibold text-white">{notification.title}</h3>
                  <p className="text-green-100 text-sm mt-1">{notification.message}</p>
                  <p className="text-green-300 text-xs mt-2">{notification.timestamp}</p>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-white text-center">No notifications</p>
          )}
        </ScrollArea>
      </div>
    </div>
  )
}

