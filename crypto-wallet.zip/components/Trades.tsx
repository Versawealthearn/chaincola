import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent } from "@/components/ui/card"

const mockTrades = [
  { id: 1, type: 'Buy', asset: 'BTC', amount: '0.1', price: '35,000', total: '3,500', date: '2023-06-01', status: 'Completed' },
  { id: 2, type: 'Sell', asset: 'ETH', amount: '2', price: '2,000', total: '4,000', date: '2023-05-30', status: 'Completed' },
  { id: 3, type: 'Buy', asset: 'USDC', amount: '1000', price: '1', total: '1,000', date: '2023-05-29', status: 'Pending' },
  { id: 4, type: 'Sell', asset: 'BTC', amount: '0.05', price: '34,000', total: '1,700', date: '2023-05-28', status: 'Completed' },
  { id: 5, type: 'Buy', asset: 'ETH', amount: '1.5', price: '1,900', total: '2,850', date: '2023-05-27', status: 'Completed' },
]

export function Trades() {
  return (
    <Card className="bg-green-800 border-green-700">
      <CardContent className="p-4">
        <h2 className="text-xl font-bold text-white mb-4">Trade History</h2>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-green-300">Type</TableHead>
              <TableHead className="text-green-300">Asset</TableHead>
              <TableHead className="text-green-300">Amount</TableHead>
              <TableHead className="text-green-300">Price (USD)</TableHead>
              <TableHead className="text-green-300">Total (USD)</TableHead>
              <TableHead className="text-green-300">Date</TableHead>
              <TableHead className="text-green-300">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mockTrades.map((trade) => (
              <TableRow key={trade.id}>
                <TableCell className={`font-medium ${trade.type === 'Buy' ? 'text-green-400' : 'text-red-400'}`}>
                  {trade.type}
                </TableCell>
                <TableCell className="text-white">{trade.asset}</TableCell>
                <TableCell className="text-white">{trade.amount}</TableCell>
                <TableCell className="text-white">{trade.price}</TableCell>
                <TableCell className="text-white">{trade.total}</TableCell>
                <TableCell className="text-white">{trade.date}</TableCell>
                <TableCell className={`${trade.status === 'Completed' ? 'text-green-400' : 'text-yellow-400'}`}>
                  {trade.status}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

