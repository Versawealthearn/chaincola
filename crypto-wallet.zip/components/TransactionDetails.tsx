import { useState } from 'react'
import { X, Download, Send } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity } from './AccountActivities'  // Import the Activity type

interface TransactionDetailsProps {
  transaction: Activity;
  onClose: () => void;
}

export function TransactionDetails({ transaction, onClose }: TransactionDetailsProps) {
  const [isPdfGenerating, setIsPdfGenerating] = useState(false);

  const generatePdf = async () => {
    setIsPdfGenerating(true);
    // In a real application, this would call an API to generate the PDF
    await new Promise(resolve => setTimeout(resolve, 2000));  // Simulate API call
    setIsPdfGenerating(false);
    // Here you would typically trigger the PDF download
    alert('PDF generated and downloaded!');
  };

  const sendPdf = async () => {
    setIsPdfGenerating(true);
    // In a real application, this would call an API to generate and send the PDF
    await new Promise(resolve => setTimeout(resolve, 2000));  // Simulate API call
    setIsPdfGenerating(false);
    alert('PDF sent to your email!');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <Card className="bg-green-800 border-green-700 w-full max-w-md">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-2xl font-bold text-white">Transaction Details</CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-green-700">
            <X className="h-6 w-6" />
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-green-300">Type</p>
              <p className="text-lg font-medium text-white">{transaction.type}</p>
            </div>
            <div>
              <p className="text-sm text-green-300">Amount</p>
              <p className="text-lg font-medium text-white">{transaction.amount} {transaction.currency}</p>
            </div>
            <div>
              <p className="text-sm text-green-300">Date</p>
              <p className="text-lg font-medium text-white">{transaction.date}</p>
            </div>
            <div>
              <p className="text-sm text-green-300">Status</p>
              <p className="text-lg font-medium text-white">{transaction.status}</p>
            </div>
            <div className="flex space-x-4 pt-4">
              <Button 
                className="flex-1 bg-green-600 text-white hover:bg-green-700" 
                onClick={generatePdf}
                disabled={isPdfGenerating}
              >
                <Download className="mr-2 h-4 w-4" />
                {isPdfGenerating ? 'Generating...' : 'Download PDF'}
              </Button>
              <Button 
                className="flex-1 bg-green-600 text-white hover:bg-green-700" 
                onClick={sendPdf}
                disabled={isPdfGenerating}
              >
                <Send className="mr-2 h-4 w-4" />
                {isPdfGenerating ? 'Sending...' : 'Send PDF'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

