import { useState } from 'react'
import { X, Copy } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function ReceiveModal({ onClose }: { onClose: () => void }) {
  const [selectedCoin, setSelectedCoin] = useState('')
  const [address, setAddress] = useState('')

  const generateAddress = (coin: string) => {
    // In a real application, this would call an API to generate a new address
    const addresses = {
      BTC: '1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2',
      ETH: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e',
      USDC: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e',
    }
    setAddress(addresses[coin as keyof typeof addresses] || '')
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(address)
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-green-800 p-6 rounded-lg w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white">Receive Cryptocurrency</h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-green-700">
            <X className="h-6 w-6" />
          </Button>
        </div>
        <Select onValueChange={(value) => { setSelectedCoin(value); generateAddress(value); }}>
          <SelectTrigger className="w-full mb-4 bg-green-700 text-white border-green-600">
            <SelectValue placeholder="Select Coin" />
          </SelectTrigger>
          <SelectContent className="bg-green-700 text-white border-green-600">
            <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
            <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
            <SelectItem value="USDC">USDC</SelectItem>
          </SelectContent>
        </Select>
        {address && (
          <div className="bg-green-700 p-4 rounded-lg mb-4">
            <p className="text-white mb-2">Your {selectedCoin} address:</p>
            <p className="text-green-300 break-all">{address}</p>
          </div>
        )}
        <Button onClick={handleCopy} className="w-full bg-green-600 text-white hover:bg-green-700 flex items-center justify-center">
          <Copy className="mr-2 h-4 w-4" /> Copy Address
        </Button>
      </div>
    </div>
  )
}

