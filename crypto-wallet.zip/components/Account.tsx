import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"

export function Account() {
  const [twoFAEnabled, setTwoFAEnabled] = useState(false)

  return (
    <div className="space-y-6">
      <Card className="bg-green-800 border-green-700">
        <CardContent className="p-4">
          <h2 className="text-xl font-bold text-white mb-4">Personal Details</h2>
          <form className="space-y-4">
            <div>
              <Label htmlFor="name" className="text-white">Full Name</Label>
              <Input id="name" placeholder="John Doe" className="bg-green-700 text-white border-green-600 placeholder-green-400" />
            </div>
            <div>
              <Label htmlFor="email" className="text-white">Email</Label>
              <Input id="email" type="email" placeholder="john@example.com" className="bg-green-700 text-white border-green-600 placeholder-green-400" />
            </div>
            <div>
              <Label htmlFor="phone" className="text-white">Phone Number</Label>
              <Input id="phone" type="tel" placeholder="+1 234 567 8900" className="bg-green-700 text-white border-green-600 placeholder-green-400" />
            </div>
            <Button className="bg-green-600 text-white hover:bg-green-700">Update Details</Button>
          </form>
        </CardContent>
      </Card>

      <Card className="bg-green-800 border-green-700">
        <CardContent className="p-4">
          <h2 className="text-xl font-bold text-white mb-4">Security</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-white font-medium">Two-Factor Authentication</h3>
                <p className="text-green-300 text-sm">Add an extra layer of security to your account</p>
              </div>
              <Switch 
                checked={twoFAEnabled} 
                onCheckedChange={setTwoFAEnabled}
              />
            </div>
            <Button className="bg-green-600 text-white hover:bg-green-700">Change Password</Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-green-800 border-green-700">
        <CardContent className="p-4">
          <h2 className="text-xl font-bold text-white mb-4">Preferences</h2>
          <div className="space-y-4">
            <div>
              <Label htmlFor="currency" className="text-white">Preferred Currency</Label>
              <Input id="currency" placeholder="USD" className="bg-green-700 text-white border-green-600 placeholder-green-400" />
            </div>
            <div>
              <Label htmlFor="language" className="text-white">Language</Label>
              <Input id="language" placeholder="English" className="bg-green-700 text-white border-green-600 placeholder-green-400" />
            </div>
            <Button className="bg-green-600 text-white hover:bg-green-700">Save Preferences</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

