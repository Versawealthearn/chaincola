function generatePdf(transaction) {
  // In a real application, you'd use a PDF generation library here
  const pdfContent = `
    Transaction Details
    -------------------
    Type: ${transaction.type}
    Amount: ${transaction.amount} ${transaction.currency}
    Date: ${transaction.date}
    Status: ${transaction.status}
  `;

  console.log('Generated PDF content:');
  console.log(pdfContent);

  // In a real application, you'd return the PDF file or a download link
  return 'pdf_file.pdf';
}

// Example usage
const transaction = {
  id: 1,
  type: 'send',
  amount: '0.1',
  currency: 'BTC',
  date: '2023-06-01',
  status: 'completed'
};

const pdfFile = generatePdf(transaction);
console.log(`PDF generated: ${pdfFile}`);

