'use client'

import React, { useState } from 'react'
import { Bell, ArrowUpRight, ArrowDownRight, RefreshCcw, Home, WalletIcon, BarChart2, LineChart, User, Eye, EyeOff, ArrowLeft } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { SendModal } from './components/SendModal'
import { ReceiveModal } from './components/ReceiveModal'
import { ConvertModal } from './components/ConvertModal'
import { BuyModal } from './components/BuyModal'
import { SellModal } from './components/SellModal'
import { NotificationsModal } from './components/NotificationsModal'
import { AccountActivities } from './components/AccountActivities'
import { Market } from './components/Market'
import { Trades } from './components/Trades'
import { Account } from './components/Account'
import LandingPage from './components/LandingPage'
import { LoginModal } from './components/LoginModal'
import { SignupModal } from './components/SignupModal'
import { ForgotPasswordModal } from './components/ForgotPasswordModal'

// Mock notifications data
const mockNotifications = [
  { id: 1, title: "Transaction Completed", message: "Your BTC purchase of 0.1 BTC has been completed.", timestamp: "2 minutes ago", read: false },
  { id: 2, title: "Price Alert", message: "ETH has increased by 5% in the last hour.", timestamp: "1 hour ago", read: false },
  { id: 3, title: "Security Update", message: "We've added new security features to protect your account.", timestamp: "1 day ago", read: true },
]

const Wallet: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [activeModal, setActiveModal] = useState<'send' | 'receive' | 'convert' | 'buy' | 'sell' | 'notifications' | 'login' | 'signup' | 'forgotPassword' | null>(null)
  const [showBalance, setShowBalance] = useState(true)
  const [notifications, setNotifications] = useState(mockNotifications)
  const [activeTab, setActiveTab] = useState<'home' | 'wallet' | 'market' | 'trades' | 'account'>('wallet')
  const [previousTab, setPreviousTab] = useState<string | null>(null)

  const toggleBalanceVisibility = () => {
    setShowBalance(!showBalance)
  }

  const unreadNotificationsCount = notifications.filter(n => !n.read).length

  const handleLogin = (email: string, password: string) => {
    // Here you would typically validate the credentials with your backend
    console.log('Login attempt:', email, password)
    setIsAuthenticated(true)
    setActiveModal(null)
  }

  const handleSignup = (email: string, password: string) => {
    // Here you would typically send the signup data to your backend
    console.log('Signup attempt:', email, password)
    setIsAuthenticated(true)
    setActiveModal(null)
  }

  const handleForgotPassword = (email: string) => {
    // Here you would typically send a password reset email
    console.log('Password reset requested for:', email)
    alert(`A password reset link has been sent to ${email}`)
    setActiveModal(null)
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    setActiveTab('wallet')
    setPreviousTab(null)
  }

  const handleTabChange = (newTab: typeof activeTab) => {
    setPreviousTab(activeTab)
    setActiveTab(newTab)
  }

  const handleBack = () => {
    if (previousTab) {
      setActiveTab(previousTab as typeof activeTab)
      setPreviousTab(null)
    }
  }

  if (!isAuthenticated) {
    return (
      <>
        <LandingPage 
          onLogin={() => setActiveModal('login')} 
          onSignup={() => setActiveModal('signup')} 
        />
        {activeModal === 'login' && (
          <LoginModal
            onClose={() => setActiveModal(null)}
            onLogin={handleLogin}
            onForgotPassword={() => setActiveModal('forgotPassword')}
          />
        )}
        {activeModal === 'signup' && (
          <SignupModal
            onClose={() => setActiveModal(null)}
            onSignup={handleSignup}
          />
        )}
        {activeModal === 'forgotPassword' && (
          <ForgotPasswordModal
            onClose={() => setActiveModal(null)}
            onSubmit={handleForgotPassword}
          />
        )}
      </>
    )
  }

  return (
    <div className="min-h-screen bg-green-900 text-white">
      <div className="max-w-4xl mx-auto p-4 pb-20 flex flex-col min-h-screen">
        {/* Header */}
        <header className="flex justify-between items-center mb-6">
          <div className="flex items-center">
            {previousTab && (
              <Button
                variant="ghost"
                size="icon"
                className="mr-2 text-white hover:bg-green-800"
                onClick={handleBack}
              >
                <ArrowLeft className="h-6 w-6" />
              </Button>
            )}
            <h1 className="text-2xl font-bold">VersaWealthEarn</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-white hover:bg-green-800 relative"
              onClick={() => setActiveModal('notifications')}
            >
              <Bell className="h-6 w-6" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {unreadNotificationsCount}
                </span>
              )}
              <span className="sr-only">Notifications</span>
            </Button>
            <Button onClick={handleLogout} className="bg-green-600 text-white hover:bg-green-700">
              Logout
            </Button>
          </div>
        </header>

        {activeTab === 'home' && (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-white">Welcome to Your VersaWealthEarn Dashboard</h2>
            <p className="text-green-300">Here's a quick overview of your portfolio and recent activities.</p>
            <Card className="bg-green-800 border-green-700">
              <CardContent className="p-4">
                <h3 className="text-xl font-semibold text-white mb-2">Portfolio Summary</h3>
                <p className="text-green-300">Total Balance: {showBalance ? '$100,000,000.60' : '••••••••••'}</p>
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <Button className="bg-green-600 text-white hover:bg-green-700" onClick={() => handleTabChange('wallet')}>View Wallet</Button>
                  <Button className="bg-green-600 text-white hover:bg-green-700" onClick={() => handleTabChange('market')}>Check Market</Button>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-green-800 border-green-700">
              <CardContent className="p-4">
                <h3 className="text-xl font-semibold text-white mb-2">Recent Activities</h3>
                <ul className="space-y-2">
                  {notifications.slice(0, 3).map((notification) => (
                    <li key={notification.id} className="text-green-300">
                      {notification.title} - {notification.timestamp}
                    </li>
                  ))}
                </ul>
                <Button 
                  className="mt-4 w-full bg-green-600 text-white hover:bg-green-700"
                  onClick={() => setActiveModal('notifications')}
                >
                  View All Notifications
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === 'wallet' && (
          <>
            {/* Balance Card */}
            <Card className="bg-green-800 border-green-700 mb-8">
              <CardContent className="p-4">
                {/* Action Buttons */}
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <Button variant="ghost" className="flex flex-col items-center py-2 h-auto text-white hover:bg-green-700" onClick={() => setActiveModal('send')}>
                    <ArrowUpRight className="h-5 w-5 mb-1" />
                    <span className="text-xs">Send</span>
                  </Button>
                  <Button variant="ghost" className="flex flex-col items-center py-2 h-auto text-white hover:bg-green-700" onClick={() => setActiveModal('receive')}>
                    <ArrowDownRight className="h-5 w-5 mb-1" />
                    <span className="text-xs">Receive</span>
                  </Button>
                  <Button variant="ghost" className="flex flex-col items-center py-2 h-auto text-white hover:bg-green-700" onClick={() => setActiveModal('convert')}>
                    <RefreshCcw className="h-5 w-5 mb-1" />
                    <span className="text-xs">Convert</span>
                  </Button>
                </div>
                
                {/* Balance */}
                <div>
                  <div className="text-sm text-green-300 flex items-center gap-2 mb-1">
                    TOTAL BALANCE 
                    <Button variant="ghost" size="icon" className="p-0 h-auto text-green-300 hover:text-white hover:bg-green-700" onClick={toggleBalanceVisibility}>
                      {showBalance ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      <span className="sr-only">{showBalance ? 'Hide' : 'Show'} balance</span>
                    </Button>
                  </div>
                  <div className="text-3xl font-semibold">
                    {showBalance ? (
                      '100,000,000.60 USD'
                    ) : (
                      '••••••••••'
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Crypto Assets */}
            <div className="space-y-4 mb-8">
              <h2 className="text-xl font-bold">Your Assets</h2>
              <Card className="bg-green-800 border-green-700">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-[#F7931A] rounded-full flex items-center justify-center">
                        <span className="text-white font-bold">₿</span>
                      </div>
                      <span className="font-medium">BITCOIN</span>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">{showBalance ? '50,000 USD' : '•••••'}</div>
                      <div className="text-sm text-green-300">{showBalance ? '1.5 BTC' : '•••••'}</div>
                    </div>
                  </div>
                  <div className="text-sm text-green-300 mb-4">1 BTC = 33,333.33 USD</div>
                  <div className="flex gap-2">
                    <Button className="flex-1 bg-green-600 text-white hover:bg-green-700" onClick={() => setActiveModal('sell')}>Sell</Button>
                    <Button className="flex-1 bg-green-600 text-white hover:bg-green-700" onClick={() => setActiveModal('buy')}>Buy</Button>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-green-800 border-green-700">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-[#627EEA] rounded-full flex items-center justify-center">
                        <span className="text-white">Ξ</span>
                      </div>
                      <span className="font-medium">ETHEREUM</span>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">{showBalance ? '30,000 USD' : '•••••'}</div>
                      <div className="text-sm text-green-300">{showBalance ? '15 ETH' : '•••••'}</div>
                    </div>
                  </div>
                  <div className="text-sm text-green-300 mb-4">1 ETH = 2,000 USD</div>
                  <div className="flex gap-2">
                    <Button className="flex-1 bg-green-600 text-white hover:bg-green-700" onClick={() => setActiveModal('sell')}>Sell</Button>
                    <Button className="flex-1 bg-green-600 text-white hover:bg-green-700" onClick={() => setActiveModal('buy')}>Buy</Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Account Activities */}
            <AccountActivities />
          </>
        )}

        {activeTab === 'market' && <Market />}
        {activeTab === 'trades' && <Trades />}
        {activeTab === 'account' && <Account />}

        {/* Bottom Navigation */}
        <div className="fixed bottom-0 left-0 right-0 bg-green-800 py-2 px-4">
          <div className="max-w-4xl mx-auto grid grid-cols-5 gap-2">
            <Button 
              variant={activeTab === 'home' ? 'default' : 'ghost'} 
              className={`flex flex-col items-center justify-center py-2 h-16 ${activeTab === 'home' ? 'bg-green-700' : 'text-white hover:bg-green-700'}`}
              onClick={() => handleTabChange('home')}
            >
              <Home className="h-5 w-5 mb-1" />
              <span className="text-xs">Home</span>
            </Button>
            <Button 
              variant={activeTab === 'wallet' ? 'default' : 'ghost'} 
              className={`flex flex-col items-center justify-center py-2 h-16 ${activeTab === 'wallet' ? 'bg-green-700' : 'text-white hover:bg-green-700'}`}
              onClick={() => handleTabChange('wallet')}
            >
              <WalletIcon className="h-5 w-5 mb-1" />
              <span className="text-xs">Wallet</span>
            </Button>
            <Button 
              variant={activeTab === 'market' ? 'default' : 'ghost'} 
              className={`flex flex-col items-center justify-center py-2 h-16 ${activeTab === 'market' ? 'bg-green-700' : 'text-white hover:bg-green-700'}`}
              onClick={() => handleTabChange('market')}
            >
              <BarChart2 className="h-5 w-5 mb-1" />
              <span className="text-xs">Market</span>
            </Button>
            <Button 
              variant={activeTab === 'trades' ? 'default' : 'ghost'} 
              className={`flex flex-col items-center justify-center py-2 h-16 ${activeTab === 'trades' ? 'bg-green-700' : 'text-white hover:bg-green-700'}`}
              onClick={() => handleTabChange('trades')}
            >
              <LineChart className="h-5 w-5 mb-1" />
              <span className="text-xs">Trades</span>
            </Button>
            <Button 
              variant={activeTab === 'account' ? 'default' : 'ghost'} 
              className={`flex flex-col items-center justify-center py-2 h-16 ${activeTab === 'account' ? 'bg-green-700' : 'text-white hover:bg-green-700'}`}
              onClick={() => handleTabChange('account')}
            >
              <User className="h-5 w-5 mb-1" />
              <span className="text-xs">Account</span>
            </Button>
          </div>
        </div>
      </div>

      {activeModal === 'send' && <SendModal onClose={() => setActiveModal(null)} />}
      {activeModal === 'receive' && <ReceiveModal onClose={() => setActiveModal(null)} />}
      {activeModal === 'convert' && <ConvertModal onClose={() => setActiveModal(null)} />}
      {activeModal === 'buy' && <BuyModal onClose={() => setActiveModal(null)} />}
      {activeModal === 'sell' && <SellModal onClose={() => setActiveModal(null)} />}
      {activeModal === 'notifications' && (
        <NotificationsModal 
          onClose={() => {
            setActiveModal(null);
            setNotifications(notifications.map(n => ({ ...n, read: true })));
          }} 
          notifications={notifications}
        />
      )}
      {activeModal === 'login' && (
          <LoginModal
            onClose={() => setActiveModal(null)}
            onLogin={handleLogin}
            onForgotPassword={() => setActiveModal('forgotPassword')}
          />
        )}
        {activeModal === 'signup' && (
          <SignupModal
            onClose={() => setActiveModal(null)}
            onSignup={handleSignup}
          />
        )}
        {activeModal === 'forgotPassword' && (
          <ForgotPasswordModal
            onClose={() => setActiveModal(null)}
            onSubmit={handleForgotPassword}
          />
        )}
    </div>
  )
}

export default Wallet

