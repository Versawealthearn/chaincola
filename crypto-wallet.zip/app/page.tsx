"use client"

import Wallet from "../wallet"

export default function SyntheticV0PageForDeployment() {
  return <Wallet />
}